#include <Arduino.h>
#include <SPI.h>
#include "gImage_test.h"

// GDEM035T81 / Good Display sample pin mapping.
// This follows the supplied vendor demo: A14/A15/A16/A17 -> 14/15/16/17.
static constexpr uint8_t EPD_BUSY = 14;
static constexpr uint8_t EPD_RST  = 15;
static constexpr uint8_t EPD_DC   = 16;
static constexpr uint8_t EPD_CS   = 17;
static constexpr uint8_t EPD_SCLK = 18;
static constexpr uint8_t EPD_MOSI = 23;

static constexpr uint16_t EPD_WIDTH  = 184;
static constexpr uint16_t EPD_HEIGHT = 384;
static constexpr uint16_t EPD_ARRAY  = EPD_WIDTH * EPD_HEIGHT / 8; // 8832

static SPISettings epdSpi(10000000, MSBFIRST, SPI_MODE0);

static inline void epdWriteByte(uint8_t value) {
    SPI.transfer(value);
}

static inline void epdCommand(uint8_t command) {
    digitalWrite(EPD_CS, LOW);
    digitalWrite(EPD_DC, LOW);
    epdWriteByte(command);
    digitalWrite(EPD_CS, HIGH);
}

static inline void epdData(uint8_t data) {
    digitalWrite(EPD_CS, LOW);
    digitalWrite(EPD_DC, HIGH);
    epdWriteByte(data);
    digitalWrite(EPD_CS, HIGH);
}

static void epdWaitBusy() {
    // Good Display sample: BUSY is high while busy, low when ready.
    while (digitalRead(EPD_BUSY) != LOW) {
        delay(1);
    }
}

static void epdHwInit() {
    digitalWrite(EPD_RST, LOW);
    delay(10);
    digitalWrite(EPD_RST, HIGH);
    delay(10);

    epdWaitBusy();

    epdCommand(0x12); // SWRESET
    epdWaitBusy();

    epdCommand(0x01); // Driver output control
    epdData((EPD_HEIGHT - 1) & 0xFF);
    epdData((EPD_HEIGHT - 1) >> 8);
    epdData(0x00);

    epdCommand(0x11); // Data entry mode
    epdData(0x01);

    epdCommand(0x44); // RAM X start/end
    epdData(0x00);
    epdData(EPD_WIDTH / 8 - 1);

    epdCommand(0x45); // RAM Y start/end
    epdData((EPD_HEIGHT - 1) & 0xFF);
    epdData((EPD_HEIGHT - 1) >> 8);
    epdData(0x00);
    epdData(0x00);

    epdCommand(0x3C); // Border waveform
    epdData(0x01);

    epdCommand(0x18); // Built-in temperature sensor
    epdData(0x80);

    epdCommand(0x4E); // RAM X address counter = 0
    epdData(0x00);

    epdCommand(0x4F); // RAM Y address counter = EPD_HEIGHT-1
    epdData((EPD_HEIGHT - 1) & 0xFF);
    epdData((EPD_HEIGHT - 1) >> 8);

    epdWaitBusy();
}

static void epdUpdate() {
    epdCommand(0x22); // Display update control
    epdData(0xF4);
    epdCommand(0x20); // Activate display update sequence
    epdWaitBusy();
}

static void epdDisplayImage(const uint8_t *image) {
    epdCommand(0x24); // Write BW image RAM; 0 = black, 1 = white
    for (uint16_t i = 0; i < EPD_ARRAY; ++i) {
        epdData(image[i]);
    }

    // Vendor sample writes 0x00 to the second RAM plane before updating.
    epdCommand(0x26);
    for (uint16_t i = 0; i < EPD_ARRAY; ++i) {
        epdData(0x00);
    }

    epdUpdate();
}

static void epdDeepSleep() {
    epdCommand(0x10);
    epdData(0x01);
    delay(100);
}

void setup() {
    Serial.begin(115200);
    delay(100);

    pinMode(EPD_BUSY, INPUT);
    pinMode(EPD_RST, OUTPUT);
    pinMode(EPD_DC, OUTPUT);
    pinMode(EPD_CS, OUTPUT);

    digitalWrite(EPD_CS, HIGH);
    digitalWrite(EPD_DC, HIGH);
    digitalWrite(EPD_RST, HIGH);

    // VSPI pins used by the Good Display sample.
    SPI.begin(EPD_SCLK, -1, EPD_MOSI, EPD_CS);
    SPI.beginTransaction(epdSpi);

    Serial.println("GDEM035T81 test: initializing...");
    Serial.printf("Framebuffer: %u bytes\n", EPD_ARRAY);

    epdHwInit();
    Serial.println("Sending test image...");
    epdDisplayImage(gImage_test);
    Serial.println("Done; entering deep sleep.");
    epdDeepSleep();

    SPI.endTransaction();
}

void loop() {
    // One-shot test. The display stays in deep sleep.
    delay(1000);
}
